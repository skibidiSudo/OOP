package hus.oop.lab7.resizable;

public interface Resizable {
    void resize(int percent);
}
