package hus.oop.lab7.resizable;

public interface GeometricObject {
    double getArea();
    double getPerimeter();
}
