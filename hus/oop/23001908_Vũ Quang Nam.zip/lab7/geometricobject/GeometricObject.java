package hus.oop.lab7.geometricobject;

public interface GeometricObject {
    double getArea();
    double getPerimeter();
}
