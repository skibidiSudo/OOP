package hus.oop.lab7.movablerectangle;

public interface Movable {
    void moveUp();
    void moveDown();
    void moveRight();
    void moveLeft();
}
