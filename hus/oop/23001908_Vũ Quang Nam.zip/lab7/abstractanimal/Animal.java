package hus.oop.lab7.abstractanimal;

public abstract class Animal {

    public Animal() {
    }

    abstract void greeting();
}
