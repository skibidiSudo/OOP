package hus.oop.lab7.movablepoint;

public interface Movable {
    void moveUp();
    void moveDown();
    void moveRight();
    void moveLeft();
}
